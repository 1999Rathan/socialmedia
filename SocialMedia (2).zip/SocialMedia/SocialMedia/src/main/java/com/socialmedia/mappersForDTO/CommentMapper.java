package com.socialmedia.mappersForDTO;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.socialmedia.RequestDTO.CommentAddRequest;
import com.socialmedia.ResponseDTO.CommentGetResponse;
import com.socialmedia.models.Comment;

@Mapper(componentModel = "spring")
public interface CommentMapper {
	
	@Mapping(source="user.id" , target = "userId")
	@Mapping(source="post.id" , target = "postId")
	@Mapping(source="user.name" , target = "userName")
	@Mapping(source="user.lastName" , target = "userLastName")
	CommentGetResponse commentToResponse(Comment comment);
	
	List<CommentGetResponse> commentGetResponses(List<Comment> comments);
	
	@Mapping(source = "userId" ,target ="user.id")
	@Mapping(source = "postId",target="post.id")
	Comment addRequestToComment(CommentAddRequest commentAddRequest);

}
