package com.socialmedia.controllerApi;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.socialmedia.RequestDTO.UserAddRequest;
import com.socialmedia.ResponseDTO.User.UserResposnse;
import com.socialmedia.services.UserService;

@RestController
@RequestMapping("/api/users")
public class UsersController {
	
	private final UserService userService;
	
	@Autowired
	public UsersController(UserService userService) {
		this.userService = userService;
	}
	
	@PostMapping("/add")
	public ResponseEntity<String> add(@RequestBody UserAddRequest userAddRequest) {
		userService.add(userAddRequest);
		return new ResponseEntity<>("User Added",HttpStatus.CREATED);
	}
	
	@GetMapping("/getall")
	public ResponseEntity<List<UserResposnse>> getALl() {
		return new ResponseEntity<>(userService.getAll(),HttpStatus.OK);
	}
	
	@GetMapping("/getbyid/{id}")
	public ResponseEntity<UserResposnse> getById(@PathVariable int id) {
		return new ResponseEntity<>(userService.getResponseById(id),HttpStatus.OK);
	}
	
	@GetMapping("/isfollowing")
	public ResponseEntity<Boolean> isFollowing(@RequestParam int userId,@RequestParam int followingId) {
		return new ResponseEntity<>(userService.isFollowing(userId, followingId),HttpStatus.OK);
	}
	
	@DeleteMapping("/delete")
	public ResponseEntity<Void> delete(@RequestParam int id) {
		userService.delete(id);
		return new ResponseEntity<>(HttpStatus.OK);
	}

}
