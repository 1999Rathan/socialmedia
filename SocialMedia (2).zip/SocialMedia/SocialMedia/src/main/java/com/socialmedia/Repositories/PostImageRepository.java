package com.socialmedia.Repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.socialmedia.models.PostImage;

public interface PostImageRepository extends JpaRepository<PostImage, Integer> {

	Optional<PostImage> findPostImageByPost_Id(int postId);
}
