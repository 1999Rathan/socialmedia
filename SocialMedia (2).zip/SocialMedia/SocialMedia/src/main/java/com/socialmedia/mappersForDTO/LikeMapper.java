package com.socialmedia.mappersForDTO;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.socialmedia.RequestDTO.LikeRequest;
import com.socialmedia.ResponseDTO.LikeResponse;
import com.socialmedia.models.Like;

@Mapper(componentModel = "spring")
public interface LikeMapper {
	
	@Mapping(source = "user.id" , target = "userId")
	@Mapping(source = "user.name" , target = "name")
	@Mapping(source = "user.lastName" , target = "lastName")
	LikeResponse likeToPostLikeResposne(Like like);
	
	@Mapping(source = "postId" , target = "post.id")
	@Mapping(source = "userId" , target = "user.id")
	Like requestToLike(LikeRequest likeRequest);
	
	List<LikeResponse> likesToLikeResponses(List<Like> likes);

}
