package com.socialmedia.services;

import java.io.IOException;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.socialmedia.Repositories.UserImageRepository;
import com.socialmedia.ResponseDTO.UserImageResponse;
import com.socialmedia.mappersForDTO.UserImageMapper;
import com.socialmedia.models.UserImage;
import com.socialmedia.utils.ImageUtil;

@Service
public class UserImageService {
	
	private final UserImageRepository userImageRepository;
	private final UserService userService;
	private final UserImageMapper userImageMapper;
	
	public UserImageService(UserImageRepository userImageRepository, UserService userService,
			UserImageMapper userImageMapper) {
		this.userImageRepository = userImageRepository;
		this.userService = userService;
		this.userImageMapper = userImageMapper;
	}
	
	public UserImageResponse upload(MultipartFile file,int userId) throws IOException {
		UserImage userImage = new UserImage();
		userImage.setData(ImageUtil.compressImage(file.getBytes()));
		userImage.setName(file.getOriginalFilename());
		userImage.setType(file.getContentType());
		userImage.setUser(userService.getById(userId));
		userImageRepository.save(userImage);
		
		return userImageMapper.userImageResponse(userImage);
	}
	
	public byte[] download(int id) {
		
		Optional<UserImage> userImage = userImageRepository.findByUser_Id(id);
 		return ImageUtil.decompressImage(userImage.get().getData());
	}

}
