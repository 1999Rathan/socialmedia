package com.socialmedia.controllerApi;

import java.io.IOException;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.socialmedia.ResponseDTO.UserImageResponse;
import com.socialmedia.services.UserImageService;

@RestController
@RequestMapping("/api/userimages")
public class UserImagesController {
	
	private final UserImageService userImageService;

	public UserImagesController(UserImageService userImageService) {
		this.userImageService = userImageService;
	}
	
	@PostMapping("/upload")
	public ResponseEntity<UserImageResponse> upload(@RequestParam("image") MultipartFile file,@RequestParam int userId) throws IOException {
		UserImageResponse response = userImageService.upload(file, userId);
		return new ResponseEntity<>(response,HttpStatus.OK);
	}
	
	@GetMapping("/download/{userId}")
	public ResponseEntity<byte[]> download(@PathVariable int userId) {
		byte[] image = userImageService.download(userId);
		return ResponseEntity.status(HttpStatus.OK).contentType(MediaType.valueOf("image/png")).body(image);
 	}

}
