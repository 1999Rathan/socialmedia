package com.socialmedia.mappersForDTO;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.socialmedia.RequestDTO.PostAddRequest;
import com.socialmedia.ResponseDTO.PostGetResponse;
import com.socialmedia.models.Post;

@Mapper(componentModel ="spring")
public interface PostMapper {
	
	@Mapping(source= "user.id" ,target = "userId")
	@Mapping(source= "user.lastName" ,target = "userLastName")
	@Mapping(source= "user.name" ,target = "userName")
	PostGetResponse postToGetResponse(Post post);
	
	@Mapping(source= "userId" ,target = "user.id")
	Post postAddRequestToPost(PostAddRequest postAddRequest);
	
	List<PostGetResponse> postsToGetResponses(List<Post> posts);

}
