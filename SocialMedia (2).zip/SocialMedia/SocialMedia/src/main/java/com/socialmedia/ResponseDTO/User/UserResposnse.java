package com.socialmedia.ResponseDTO.User;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserResposnse {
	
	private int id;
	private String name;
	private String lastName;
	private String email;
	private List<UserFollowerResponse> followers;
	private List<UserFollowingResposne> following;

}
