package com.socialmedia.controllerApi;

public class PostsController {

}
