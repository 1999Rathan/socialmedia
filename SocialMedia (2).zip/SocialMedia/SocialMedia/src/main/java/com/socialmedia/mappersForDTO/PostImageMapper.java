package com.socialmedia.mappersForDTO;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.socialmedia.ResponseDTO.PostImageResponse;
import com.socialmedia.models.PostImage;

@Mapper(componentModel = "spring")
public interface PostImageMapper {
	
	@Mapping(source = "post.id" ,target = "postId")
	PostImageResponse imageToResponse(PostImage postImage);

}
