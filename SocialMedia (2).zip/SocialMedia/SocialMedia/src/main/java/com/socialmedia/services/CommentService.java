package com.socialmedia.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.socialmedia.Repositories.CommentRepository;
import com.socialmedia.RequestDTO.CommentAddRequest;
import com.socialmedia.RequestDTO.CommentUpdateRequest;
import com.socialmedia.ResponseDTO.CommentGetResponse;
import com.socialmedia.mappersForDTO.CommentMapper;
import com.socialmedia.models.Comment;

@Service
public class CommentService {
	
	private final CommentRepository commentRepository;
	private final CommentMapper commentMapper;
	
	public CommentService(CommentRepository commentRepository, CommentMapper commentMapper) {
		this.commentRepository = commentRepository;
		this.commentMapper = commentMapper;
	}
	
	public void add(CommentAddRequest commentAddRequest) {
		Comment comment = commentMapper.addRequestToComment(commentAddRequest);
		commentRepository.save(comment);
	}
	
	public List<CommentGetResponse> getAll() {
		List<Comment> comments = commentRepository.findAll();
		return commentMapper.commentGetResponses(comments);
 	}
	
	public CommentGetResponse getById(int id) {
		Comment comment = commentRepository.findById(id).orElse(null);
		return commentMapper.commentToResponse(comment);
	}
	
	public List<CommentGetResponse> getAllByPost(int postId){
        List<Comment> comments = commentRepository.findALlByPost_Id(postId);
        return commentMapper.commentGetResponses(comments);
    }
	
	public List<CommentGetResponse> getAllByUser(int userId) {
		List<Comment> comments = commentRepository.findAllByUser_Id(userId);
		return commentMapper.commentGetResponses(comments);
	}
	
	public void update(int id,CommentUpdateRequest commentUpdateRequest) {
		Comment commenToUpdate = commentRepository.findById(id).orElse(null);
		if(commenToUpdate!=null) {
			commenToUpdate.setDescription(commentUpdateRequest.getDescription());
		}
	}

	public void delete(int id) {
		commentRepository.deleteById(id);
	}
}
