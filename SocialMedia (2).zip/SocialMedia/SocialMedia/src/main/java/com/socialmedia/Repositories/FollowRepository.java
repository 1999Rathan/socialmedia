package com.socialmedia.Repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.socialmedia.models.Follow;

@Repository
public interface FollowRepository extends JpaRepository<Follow, Integer> {

	List<Follow> findAllByUser_Id(int userId);
	Optional<Follow> findByUser_IdAndFollowing_Id(int userId,int followingId);
}
