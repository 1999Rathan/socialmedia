package com.socialmedia.mappersForDTO;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.socialmedia.RequestDTO.UserAddRequest;
import com.socialmedia.ResponseDTO.User.UserFollowerResponse;
import com.socialmedia.ResponseDTO.User.UserFollowingResposne;
import com.socialmedia.ResponseDTO.User.UserResposnse;
import com.socialmedia.models.Follow;
import com.socialmedia.models.User;

@Mapper(componentModel = "spring")
public interface UserMapper {

	@Mapping(source="user.id" ,target = "userId")
	@Mapping(source="user.name" ,target = "name")
	@Mapping(source="user.lastName" ,target = "lastName")
	UserFollowerResponse followToFollowingResposne(Follow follow);
	
	@Mapping(source="following.id" ,target = "userId")
	@Mapping(source="following.lastName" ,target = "lastName")
	@Mapping(source="following.name" ,target = "name")
	UserFollowingResposne followToFollowingResposnse(Follow follow);
	
	@Mapping(source="followers" ,target = "followers")
	@Mapping(source="following" ,target = "following")
	UserResposnse userToResposne(User user);
	
	User requestToUser(UserAddRequest userAddRequest);
	
	List<UserResposnse> usersToResponses(List<User> users);
	
	List<UserFollowingResposne> followsToFollowingResponses(List<Follow> follows);
	
}
