package com.socialmedia.services;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.springframework.stereotype.Service;

import com.socialmedia.Repositories.PostRepository;
import com.socialmedia.RequestDTO.PostAddRequest;
import com.socialmedia.ResponseDTO.PostGetResponse;
import com.socialmedia.ResponseDTO.User.UserFollowingResposne;
import com.socialmedia.mappersForDTO.PostMapper;
import com.socialmedia.models.Post;

@Service
public class PostService {
	
	private final PostRepository postRepository;
	private final PostMapper postMapper;
	private final UserService userService;
	
	public PostService(PostRepository postRepository, PostMapper postMapper, UserService userService) {
		this.postRepository = postRepository;
		this.postMapper = postMapper;
		this.userService = userService;
	}
	
	public List<PostGetResponse> getAll() {
		List<Post> posts = postRepository.findAll();
		return postMapper.postsToGetResponses(posts);
	}
	
	public PostGetResponse getResponseById(int id) {
		Post post = postRepository.findById(id).orElse(null);
		return postMapper.postToGetResponse(post);
	}
	
	public Post getById(int id) {
		return postRepository.findById(id).get();
	}
	
	public List<PostGetResponse> getByUserFollowing(int userId) {
		List<UserFollowingResposne> follows = userService.getUserFollowing(userId);
		List<Post> set = new ArrayList<>();
		
		for (UserFollowingResposne user : follows) {
			set.addAll(postRepository.findAllByUser_IdOrderByIdDesc(user.getUserId()));
		}
		
		set.sort(Comparator.comparing(Post::getId).reversed());
		
		return postMapper.postsToGetResponses(set);
 	}
	
	public int add(PostAddRequest postAddRequest) {
		Post post = postMapper.postAddRequestToPost(postAddRequest);
		postRepository.save(post);
		return post.getId();
	}
	
	public void delete(int id) {
		postRepository.deleteById(id);
	}

}
