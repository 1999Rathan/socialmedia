package com.socialmedia.Repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.socialmedia.models.UserImage;

public interface UserImageRepository extends JpaRepository<UserImage, Integer> {

	Optional<UserImage> findByUser_Id(int userId);
	
}
