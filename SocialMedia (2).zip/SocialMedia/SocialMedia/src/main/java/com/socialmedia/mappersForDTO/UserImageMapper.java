package com.socialmedia.mappersForDTO;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.socialmedia.ResponseDTO.UserImageResponse;
import com.socialmedia.models.UserImage;

@Mapper(componentModel = "spring")
public interface UserImageMapper {
	
	@Mapping(source="user.id", target = "userId")
	UserImageResponse userImageResponse(UserImage userImage);

}
