package com.socialmedia.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.socialmedia.Repositories.FollowRepository;
import com.socialmedia.Repositories.UserRepository;
import com.socialmedia.RequestDTO.UserAddRequest;
import com.socialmedia.ResponseDTO.User.UserFollowingResposne;
import com.socialmedia.ResponseDTO.User.UserResposnse;
import com.socialmedia.mappersForDTO.UserMapper;
import com.socialmedia.models.Follow;
import com.socialmedia.models.User;

@Service
public class UserService {
	
	private final UserMapper userMapper;
	private final UserRepository userRepository;
	private final FollowRepository followRepository;
	
	@Autowired
	public UserService(UserMapper userMapper, UserRepository userRepository, FollowRepository followRepository) {
		
		this.userMapper = userMapper;
		this.userRepository = userRepository;
		this.followRepository = followRepository;
	}
	
	public void add(UserAddRequest userAddRequest) {
		User user = userMapper.requestToUser(userAddRequest);
		userRepository.save(user);
	}
	
	public List<UserResposnse> getAll() {
		return userMapper.usersToResponses(userRepository.findAll());
	}
	
	public User getById(int id){
        return userRepository.findById(id).get();
    }
	
	public UserResposnse getResponseById(int id) {
		User user = userRepository.findById(id).orElse(null);
		return userMapper.userToResposne(user);
	}
	
	public UserResposnse getByEmail(String email) {
		User user = userRepository.findByEmail(email);
		return userMapper.userToResposne(user);
	}
	
	public List<UserFollowingResposne> getUserFollowing(int userId) {
		return userMapper.followsToFollowingResponses(followRepository.findAllByUser_Id(userId));
	}
	
	public boolean isFollowing(int userId,int followingId) {
		Optional<Follow> follow = followRepository.findByUser_IdAndFollowing_Id(userId, followingId);
		return follow.isPresent();
	}
	
	public void delete(int id) {
		userRepository.deleteById(id);
	}
}
