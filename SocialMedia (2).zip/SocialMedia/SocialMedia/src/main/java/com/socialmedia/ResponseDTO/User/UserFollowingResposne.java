package com.socialmedia.ResponseDTO.User;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserFollowingResposne {
	
	private int userId;
	private String name;
	private String lastName;

}
